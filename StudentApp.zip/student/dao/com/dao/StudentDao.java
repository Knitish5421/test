package com.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;

import com.dto.QualificationDto;
import com.dto.StudentDto;
import com.service.MyBatisUtil;

public class StudentDao {
	private static final Logger OUT = Logger.getLogger(StudentDao.class);

	public List<StudentDto> getAllStudent() throws Exception {
		SqlSession sqlSession = null;
		List<StudentDto> getAllStudent = null;
		try {
			OUT.info("getting all details Query started for executing");
			sqlSession = MyBatisUtil.getSqlSessionFactory().openSession();
			getAllStudent = sqlSession.selectList("StudentMapper.getStudents");
		} catch (Exception e) {
			OUT.error("Exception while getting all details of student ", e);

		} finally {
			if (sqlSession != null) {
				sqlSession.close();
			}

		}
		OUT.info("getting all details Query sucessfully excuted");
		return getAllStudent;
	}

	public void insertStudent(StudentDto studentDto) throws Exception {
		SqlSession sqlSession = null;
		try {
			OUT.info("insert query started  for executing");
			sqlSession = MyBatisUtil.getSqlSessionFactory().openSession();
			sqlSession.insert("StudentMapper.insert", studentDto);
			sqlSession.commit();
			OUT.info("insert query sucessfully excuted");
		} catch (Exception e) {
			if (sqlSession != null)
				sqlSession.rollback();
			throw e;
		} finally {
			if (sqlSession != null) {
				sqlSession.close();
			}

		}

	}

	public void insertQualification(QualificationDto qualificationDto) throws Exception {
		SqlSession sqlSession = null;
		try {
			OUT.info("insert Qualification query started  for executing");
			sqlSession = MyBatisUtil.getSqlSessionFactory().openSession();
			sqlSession.insert("StudentMapper.insertQualification", qualificationDto);
			sqlSession.commit();
			OUT.info("insert Qualification query sucessfully excuted");
		} catch (Exception e) {
			if (sqlSession != null)
				sqlSession.rollback();
			throw e;
		} finally {
			if (sqlSession != null) {
				sqlSession.close();
			}

		}

	}

	public void deleteQualificationByStudentId(int studentId) throws Exception {
		SqlSession sqlSession = null;
		try {
			OUT.info("delete QualificationByStudentId query started  for executing");
			sqlSession = MyBatisUtil.getSqlSessionFactory().openSession();
			sqlSession.delete("StudentMapper.deleteQualificationByStudentId", studentId);
			sqlSession.commit();
			OUT.info("delete QualificationByStudentId query sucessfully excuted");
		} catch (Exception e) {
			if (sqlSession != null)
				sqlSession.rollback();
			throw e;
		} finally {
			if (sqlSession != null) {
				sqlSession.close();
			}
		}
	}

	public void deleteStudentDetailById(int id) throws Exception {
		SqlSession sqlSession = null;
		try {
			OUT.info("delete StudentDetailById query started  for executing");
			sqlSession = MyBatisUtil.getSqlSessionFactory().openSession();
			sqlSession.delete("StudentMapper.deleteStudentDetailById", id);
			sqlSession.commit();
			OUT.info("delete StudentDetailById query sucessfully excuted");
		} catch (Exception e) {
			if (sqlSession != null)
				sqlSession.rollback();
			throw e;
		} finally {
			if (sqlSession != null) {
				sqlSession.close();
			}
		}
	}

	public StudentDto getByIdStudentDetails(int id) throws Exception {
		SqlSession sqlSession = null;
		try {
			OUT.info("getByIdStudentDetails query started  for executing");
			sqlSession = MyBatisUtil.getSqlSessionFactory().openSession();
			return sqlSession.selectOne("StudentMapper.detailsById", id);

		} catch (Exception e) {
			throw e;
		} finally {
			if (sqlSession != null) {
				sqlSession.close();
			}
		}

	}

	public void updateStudent(StudentDto studentDto) throws Exception {
		SqlSession sqlSession = null;
		try {
			OUT.info("updateStudent query started  for executing");
			sqlSession = MyBatisUtil.getSqlSessionFactory().openSession();
			sqlSession.update("StudentMapper.updateStudent", studentDto);
			sqlSession.commit();
			OUT.info("updateStudent query sucessfully excuted");
		} catch (Exception e) {
			if (sqlSession != null)
				sqlSession.rollback();
			throw e;
		} finally {
			if (sqlSession != null) {
				sqlSession.close();
			}

		}

	}

}
