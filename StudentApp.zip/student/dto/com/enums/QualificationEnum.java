package com.enums;

public enum QualificationEnum {
	TENTH("10th"),PU("pu"),GRADUATION("graduation");
	
	String Value;
	private QualificationEnum(String value) {
		Value = value;
	}
	public String getValue() {
		return Value;
	}
	public void setValue(String value) {
		Value = value;
	}
	

}
