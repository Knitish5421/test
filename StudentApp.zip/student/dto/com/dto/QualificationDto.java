package com.dto;

import com.enums.QualificationEnum;

public class QualificationDto {
	private int           id;
	private Integer       studentId;
	private String        instituteName;
	private Integer       passingYear;
	private Integer       marks;
	private String        grade;
	private QualificationEnum qualification;
	
	public QualificationEnum getQualification() {
		return qualification;
	}
	public void setQualification(QualificationEnum qualification) {
		this.qualification = qualification;
	}
	public String getInstituteName() {
		return instituteName;
	}
	public void setInstituteName(String instituteName) {
		this.instituteName = instituteName;
	}
	public Integer getMarks() {
		return marks;
	}
	public void setMarks(Integer marks) {
		this.marks = marks;
	}
	public Integer getStudentId() { 
		return studentId;
	}
	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}
	
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public Integer getPassingYear() {
		return passingYear;
	}
	public void setPassingYear(Integer passingYear) {
		this.passingYear = passingYear;
	}
	
	public QualificationDto addGrades(int marks1, QualificationDto qualDtopu) {
		if (marks1 >=75) {
			qualDtopu.setGrade("A");
		}
		if (marks1 >=45 && marks1 < 75) {
			qualDtopu.setGrade("B");
		}
		if (marks1 < 45) {
			qualDtopu.setGrade("C");
		}
		return qualDtopu;
	
		
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "QualificationDto [id=" + id + ", studentId=" + studentId + ", qualification=" + qualification
				+ ", instituteName=" + instituteName + ", passingYear=" + passingYear + ", marks=" + marks + ", grade="
				+ grade + "]";
	}
	
	

}
