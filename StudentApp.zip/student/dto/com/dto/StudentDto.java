package com.dto;

import java.util.ArrayList;
import java.util.List;

public class StudentDto  {
	private Integer       id;
	private String        name;
	private String        address;
	private Integer		  age;
	private String 		  gender;
	private List<QualificationDto> qualificationList = new ArrayList<QualificationDto>();

	public String getName() {
		return name;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getAge() {
		return age;
	}
	
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public List<QualificationDto> getQualificationList() {
		return qualificationList;
	}
	public void setQualificationList(List<QualificationDto> qualificationList) {
		this.qualificationList = qualificationList;
	}
	 
}
