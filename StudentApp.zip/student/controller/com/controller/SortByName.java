package com.controller;

import java.util.Comparator;

import org.apache.log4j.Logger;

public class SortByName implements Comparator<StudentVo> {
	private static final Logger OUT = Logger.getLogger(SortByName.class);
	int value = 0;

	public int compare(StudentVo o1, StudentVo o2) {

		try {
			OUT.info("sorting started by name in SortByName class.");
			value = o1.getName().toLowerCase().compareTo(o2.getName().toLowerCase());
		} catch (Exception e) {
			System.out.println("exception occure while sorting student details by name:" + e.getMessage());
		}
		OUT.info("sorting completed by name in SortByName class.");
		return value;
	}

}