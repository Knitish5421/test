package com.controller;

import java.util.Comparator;

import org.apache.log4j.Logger;

public class SortByYrsDsc implements Comparator<StudentVo> {
	private static final Logger OUT = Logger.getLogger(SortByYrsDsc.class);
	public int compare(StudentVo s1, StudentVo s2) {
		int value =0;
	try
	{
		OUT.info("sorting started based on Graduation PassingYear by descending order in SortByYrsDsc class.");
		value =  (s2.getGraduationPassoutYear() == null?0:s2.getGraduationPassoutYear() ) - (s1.getGraduationPassoutYear() == null?0:s1.getGraduationPassoutYear());
	}
	catch (Exception e)
	{
   		System.out.println("exception occure while sorting student details by GraduationPassoutYear in descending order :"+e.getMessage());

	}
	OUT.info("sorting completed based on Graduation PassingYear by descending order in SortByYrsDsc class.");
	return value;
	}

}
