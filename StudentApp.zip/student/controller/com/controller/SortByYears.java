package com.controller;

import java.util.Comparator;

import org.apache.log4j.Logger;

public class SortByYears implements Comparator<StudentVo> {
	private static final Logger OUT = Logger.getLogger(SortByYears.class);
	public int compare(StudentVo s1, StudentVo s2) {
		int value =0;
	try
	{
		OUT.info("sorting started based on Graduation PassingYear by ascending order in SortByYears class.");
		value =  (s1.getGraduationPassoutYear() == null?0:s1.getGraduationPassoutYear() ) - (s2.getGraduationPassoutYear() == null?0:s2.getGraduationPassoutYear());
	}
	catch (Exception e) {
   		System.out.println("exception occure while sorting student details by GraduationPassoutYear in ascending order :"+e.getMessage());

	}
	OUT.info("sorting completed based on Graduation Passing Year by ascending order in SortByYears class.");
	return value;
	}
    }
    



	