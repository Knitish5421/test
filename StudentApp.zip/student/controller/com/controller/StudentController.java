package com.controller;

import java.util.Collections;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.dto.StudentDto;
import com.service.StudentService;
//this rest api for Angular
@Controller
public class StudentController {
	private static final Logger OUT = Logger.getLogger(StudentController.class);

	StudentService studentService = new StudentService();

	@RequestMapping(value = "/show", produces = "application/json", method = RequestMethod.GET)
	public ResponseEntity<List<StudentVo>> getSummary() throws Exception {
		OUT.info("process of getting student details started in controller");
		List<StudentVo> studentList = studentService.getAllStudent();
		Collections.sort(studentList, new SortByName());
		OUT.info("process of getting student details completed in controller");
		return new ResponseEntity<List<StudentVo>>(studentList, HttpStatus.OK);
	}

	@RequestMapping(value = "/add", produces = "application/json", method = RequestMethod.POST)
	public ResponseEntity<?> insertStudent(@RequestBody StudentDto studentDto) throws Exception {
		OUT.info("process of adding student details started in controller");
		studentService.addStudent(studentDto);
		OUT.info("process of adding student details completed in controller");
		return new ResponseEntity<String>(HttpStatus.OK);
	}

	@RequestMapping(value = "/dataById/{id}", produces = "application/json", method = RequestMethod.GET)
	public ResponseEntity<?> dataById(@PathVariable("id") int id) throws Exception {
		OUT.info("getting student details by id started in controller");
		StudentVo studentListById = studentService.getByIdStudentDetails(id);
		OUT.info("getting student details by id completed in controller");
		return new ResponseEntity<StudentVo>(studentListById, HttpStatus.OK);
	}

	@RequestMapping(value = "/delete/{id}", produces = "application/json", method = RequestMethod.GET)
	public ResponseEntity<?> deleteStudent(@PathVariable("id") int id) throws Exception {
		OUT.info("process of deleting student details started in controller");
		studentService.deleteByIdStudentDetails(id);
		OUT.info("process of deleting student details completed in controller");
		return new ResponseEntity<String>(HttpStatus.OK);
	}

	@RequestMapping(value = "/edit", produces = "application/json", method = RequestMethod.POST)
	public ResponseEntity<?> editStudent(@RequestBody StudentDto studentDto) throws Exception {
		OUT.debug("edting process started");
		studentService.updateStudent(studentDto);
		OUT.debug("edting process completed");
		return new ResponseEntity<String>(HttpStatus.OK);
	}

	@RequestMapping(value = "/sort", produces = "application/json", method = RequestMethod.GET)
	public ResponseEntity<?> sortBygraduationPassoutYear() throws Exception {
		OUT.debug("sorting ascending process started");
		List<StudentVo> studentList = studentService.getAllStudent();
		Collections.sort(studentList, new SortByYears());
		OUT.debug("sorting ascending process completed");
		return new ResponseEntity<List<StudentVo>>(studentList, HttpStatus.OK);
	}

	@RequestMapping(value = "/sortDsc", produces = "application/json", method = RequestMethod.GET)
	public ResponseEntity<?> sortBygraduationPassoutYearInDscOrder() throws Exception {
		OUT.debug("sorting descending process started");
		List<StudentVo> studentList = studentService.getAllStudent();
		Collections.sort(studentList, new SortByYrsDsc());
		OUT.debug("sorting descending process completed");
		return new ResponseEntity<List<StudentVo>>(studentList, HttpStatus.OK);
	}

}

/* this rest api  controller for angular js
 package com.controller;

import java.util.Collections;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.dto.StudentDto;
import com.service.StudentService;

@Controller
public class StudentController {
	private static final Logger OUT = Logger.getLogger(StudentController.class);

	StudentService studentService = new StudentService();

	@RequestMapping(value = "/show", produces = "application/json", method = RequestMethod.GET)
	public ResponseEntity<List<StudentVo>> getSummary() throws Exception {
		OUT.info("process of getting student details started in controller");
		List<StudentVo> studentList = studentService.getAllStudent();
		Collections.sort(studentList, new SortByName());
		OUT.info("process of getting student details completed in controller");
		return new ResponseEntity<List<StudentVo>>(studentList, HttpStatus.OK);
	}

	@RequestMapping(value = "/add", produces = "application/json", method = RequestMethod.POST)
	public ResponseEntity<?> insertStudent(@RequestBody StudentDto studentDto) throws Exception {
		OUT.info("process of adding student details started in controller");
		studentService.addStudent(studentDto);
		OUT.info("process of adding student details completed in controller");
		return new ResponseEntity<String>(HttpStatus.OK);
	}

	@RequestMapping(value = "/dataById/{id}", produces = "application/json", method = RequestMethod.POST)
	public ResponseEntity<?> dataById(@PathVariable("id") int id) throws Exception {
		OUT.info("getting student details by id started in controller");
		StudentVo studentListById = studentService.getByIdStudentDetails(id);
		OUT.info("getting student details by id completed in controller");
		return new ResponseEntity<StudentVo>(studentListById, HttpStatus.OK);
	}

	@RequestMapping(value = "/delete/{id}", produces = "application/json", method = RequestMethod.POST)
	public ResponseEntity<?> deleteStudent(@PathVariable("id") int id) throws Exception {
		OUT.info("process of deleting student details started in controller");
		studentService.deleteByIdStudentDetails(id);
		OUT.info("process of deleting student details completed in controller");
		return new ResponseEntity<String>(HttpStatus.OK);
	}

	@RequestMapping(value = "/edit", produces = "application/json", method = RequestMethod.POST)
	public ResponseEntity<?> editStudent(@RequestBody StudentDto studentDto) throws Exception {
		OUT.debug("edting process started");
		studentService.updateStudent(studentDto);
		OUT.debug("edting process completed");
		return new ResponseEntity<String>(HttpStatus.OK);
	}

	@RequestMapping(value = "/sort", produces = "application/json", method = RequestMethod.GET)
	public ResponseEntity<?> sortBygraduationPassoutYear() throws Exception {
		OUT.debug("sorting ascending process started");
		List<StudentVo> studentList = studentService.getAllStudent();
		Collections.sort(studentList, new SortByYears());
		OUT.debug("sorting ascending process completed");
		return new ResponseEntity<List<StudentVo>>(studentList, HttpStatus.OK);
	}

	@RequestMapping(value = "/sortDsc", produces = "application/json", method = RequestMethod.GET)
	public ResponseEntity<?> sortBygraduationPassoutYearInDscOrder() throws Exception {
		OUT.debug("sorting descending process started");
		List<StudentVo> studentList = studentService.getAllStudent();
		Collections.sort(studentList, new SortByYrsDsc());
		OUT.debug("sorting descending process completed");
		return new ResponseEntity<List<StudentVo>>(studentList, HttpStatus.OK);
	}

}

 */
