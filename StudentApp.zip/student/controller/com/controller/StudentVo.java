package com.controller;

public class StudentVo {
	private Integer id;
	private String name;
	private Integer age;
	private String tenthInstituteName;
	private Integer tenthPassoutYear;
	private Integer tenthMarks;
	private String puInstituteName;
	private Integer puPassoutYear;
	private Integer puMarks;
	private String graduationInstituteName;
	private Integer graduationPassoutYear;
	private Integer graduationMarks;
	private Integer       studentId;
	private String        qualification;
	private String        address;
	private String 		  gender;
	private String        gradeTenth;
	private String        gradePu;
	private String        gradeGraduation;
	

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	
	public String getTenthInstituteName() {
		return tenthInstituteName;
	}
	public void setTenthInstituteName(String tenthInstituteName) {
		this.tenthInstituteName = tenthInstituteName;
	}
	public Integer getTenthPassoutYear() {
		return tenthPassoutYear;
	}
	public void setTenthPassoutYear(Integer tenthPassoutYear) {
		this.tenthPassoutYear = tenthPassoutYear;
	}
	public Integer getTenthMarks() {
		return tenthMarks;
	}
	public void setTenthMarks(Integer tenthMarks) {
		this.tenthMarks = tenthMarks;
	}
	public String getPuInstituteName() {
		return puInstituteName;
	}
	public void setPuInstituteName(String puInstituteName) {
		this.puInstituteName = puInstituteName;
	}
	public Integer getPuPassoutYear() {
		return puPassoutYear;
	}
	public void setPuPassoutYear(Integer puPassoutYear) {
		this.puPassoutYear = puPassoutYear;
	}
	public Integer getPuMarks() {
		return puMarks;
	}
	public void setPuMarks(Integer puMarks) {
		this.puMarks = puMarks;
	}
	public String getGraduationInstituteName() {
		return graduationInstituteName;
	}
	public void setGraduationInstituteName(String graduationInstituteName) {
		this.graduationInstituteName = graduationInstituteName;
	}
	public Integer getGraduationPassoutYear() {
		return graduationPassoutYear;
	}
	public void setGraduationPassoutYear(Integer graduationPassoutYear) {
		this.graduationPassoutYear = graduationPassoutYear;
	}
	public Integer getGraduationMarks() {
		return graduationMarks;
	}
	public void setGraduationMarks(Integer graduationMarks) {
		this.graduationMarks = graduationMarks;
	}
	public Integer getStudentId() {
		return studentId;
	}
	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getGradeTenth() {
		return gradeTenth;
	}
	public void setGradeTenth(String gradeTenth) {
		this.gradeTenth = gradeTenth;
	}
	public String getGradePu() {
		return gradePu;
	}
	public void setGradePu(String gradePu) {
		this.gradePu = gradePu;
	}
	public String getGradeGraduation() {
		return gradeGraduation;
	}
	public void setGradeGraduation(String gradeGraduation) {
		this.gradeGraduation = gradeGraduation;
	}
}
