package com.service;

import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import com.controller.StudentVo;
import com.dao.StudentDao;
import com.dto.QualificationDto;
import com.dto.StudentDto;
import com.enums.QualificationEnum;

public class StudentService {
	private static final Logger OUT = Logger.getLogger(StudentService.class);
	
	public List<StudentVo> getAllStudent() throws Exception {
		OUT.info("getting all details of student process started");
		List<StudentDto> studentDtoDetailsList = new ArrayList<StudentDto>();
		List<StudentVo> studentVoList = new ArrayList<StudentVo>();
		List<QualificationDto> qualification = new ArrayList<QualificationDto>();
		StudentService studentService = new StudentService();
		StudentDao studentDao = new StudentDao();
		StudentVo studentVo = null;
		studentDtoDetailsList = studentDao.getAllStudent();
		for (StudentDto studentDto : studentDtoDetailsList) {
			studentVo = new StudentVo();
			studentVo.setId(studentDto.getId());
			studentVo.setName(studentDto.getName());
			studentVo.setAge(studentDto.getAge());
			qualification = studentDto.getQualificationList();
			studentService.setQualificationForStudents(qualification, studentVo, studentDto);
			studentVoList.add(studentVo);
		}
		OUT.info("getting all details of student process completed");
		return studentVoList;

	}

	public void addStudent(StudentDto studentDto) {
		OUT.info("adding details of student process started");
		List<QualificationDto> qualificationlist = studentDto.getQualificationList();
		StudentDao studentDao = new StudentDao();
		try {
			
			studentDao.insertStudent(studentDto);
			for (QualificationDto qualificationDto : qualificationlist) {
				qualificationDto.setStudentId(studentDto.getId());
				qualificationDto.addGrades(qualificationDto.getMarks(), qualificationDto);
				studentDao.insertQualification(qualificationDto);
			}
			OUT.info("adding details of student process completed");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	public void updateStudent(StudentDto studentDto) throws Exception {
		OUT.info("updating details of student process started");
		List<QualificationDto> qualificationlist = studentDto.getQualificationList();
		StudentDao studentDao = new StudentDao();
		studentDao.updateStudent(studentDto);
		studentDao.deleteQualificationByStudentId(studentDto.getId());
		for (QualificationDto qualificationDto : qualificationlist) {
			qualificationDto.setStudentId(studentDto.getId());
			qualificationDto.addGrades(qualificationDto.getMarks(), qualificationDto);
			studentDao.insertQualification(qualificationDto);
		}
		OUT.info("updating details of student process completed");
	}

	public void deleteByIdStudentDetails(int id) throws Exception {
		StudentDao studentDao = new StudentDao();
		OUT.info("delete details of student process started");
		studentDao.deleteStudentDetailById(id);
		OUT.info("delete details of student process completed");

	}

	public StudentVo getByIdStudentDetails(int id) throws Exception {
		OUT.info("getting details of student by id  process started");
		StudentDto StudentDto = null;
		List<QualificationDto> qualificationlist = new ArrayList<QualificationDto>();
		StudentService studentService = new StudentService();
		StudentVo studentVo = new StudentVo();
		StudentDao studentDao = new StudentDao();
		StudentDto = studentDao.getByIdStudentDetails(id);
		qualificationlist = StudentDto.getQualificationList();
		studentVo.setName(StudentDto.getName());
		studentVo.setId(StudentDto.getId());
		studentVo.setAddress(StudentDto.getAddress());
		studentVo.setAge(StudentDto.getAge());
		studentVo.setGender(StudentDto.getGender());
		studentVo = studentService.setQualificationForStudents(qualificationlist, studentVo, StudentDto);
		OUT.info("getting details of student by id  process completed");
		return studentVo;

	}
	public StudentVo setQualificationForStudents(List<QualificationDto> qualificationlist, StudentVo studentVo,
			StudentDto studentDto) {
		OUT.info("setting qualification  details of student  process started");
		for (QualificationDto qualificationDto : qualificationlist) {
			if (studentDto.getId() == qualificationDto.getStudentId()) 
		    {
				if (qualificationDto.getQualification().toString().equals(QualificationEnum.TENTH.toString())) 
				{
					studentVo.setStudentId(qualificationDto.getStudentId());
					studentVo.setTenthInstituteName(qualificationDto.getInstituteName());
					studentVo.setTenthMarks(qualificationDto.getMarks());
					studentVo.setTenthPassoutYear(qualificationDto.getPassingYear());
					studentVo.setQualification(QualificationEnum.TENTH.getValue());
					studentVo.setGradeTenth(qualificationDto.getGrade());
			  }
				if (qualificationDto.getQualification().toString().equals(QualificationEnum.PU.toString())) 
				{
					studentVo.setStudentId(qualificationDto.getStudentId());
					studentVo.setPuInstituteName(qualificationDto.getInstituteName());
					studentVo.setPuMarks(qualificationDto.getMarks());
					studentVo.setPuPassoutYear(qualificationDto.getPassingYear());
					studentVo.setQualification(QualificationEnum.PU.getValue());
					studentVo.setGradePu(qualificationDto.getGrade());
				}

				if (qualificationDto.getQualification().toString().equals(QualificationEnum.GRADUATION.toString())) 
				{
					studentVo.setStudentId(qualificationDto.getStudentId());
					studentVo.setGraduationInstituteName(qualificationDto.getInstituteName());
					studentVo.setGraduationMarks(qualificationDto.getMarks());
					studentVo.setGraduationPassoutYear(qualificationDto.getPassingYear());
					studentVo.setQualification(QualificationEnum.GRADUATION.getValue());
					studentVo.setGradeGraduation(qualificationDto.getGrade());
				}
			}
		}
		OUT.info("setting qualification  details of student  process completed");
		return studentVo;
	}
}
