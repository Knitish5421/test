
var app = angular.module("StudentApp", ['ui.router']);
app.config(function($stateProvider, $urlRouterProvider) {
	
$urlRouterProvider.otherwise('/summary');	

$stateProvider

.state('summary', { 
    url : '/summary', 
    templateUrl : "pages/StudentSummary.html", 
    controller : "studentSummaryCtrl"
}) 
.state('registration', { 
    url : '/registration', 
    templateUrl : "pages/StudentRegistration.html", 
    controller : "studentRegCtrl"
})

.state('edit', { 
    url : '/edit:id', 
   // params: {obj : null},
    templateUrl : "pages/StudentRegistration.html", 
    controller : "studentEditctrl"
})

})


