app.controller("studentSummaryCtrl", function ($scope,$log,$state,studentService){

	function getStudentDetails() 
	{
		studentService.getAll().then(function(result){
	     $scope.students=result.data;
		 },function(error){
			  $log.error('Some Error in Getting Records.', error);	 
		 });  
	} 
	$scope.initLoad= function()
	{
		getStudentDetails();
	}
	
	$scope.addStudent = function()
	{
		$state.go('registration');
	}
	$scope.deleteStudent =function(id)
	{
		studentService.deleteStudent(id).then(function(result){
			getStudentDetails();
		 },function errorCallback(response) {
				alert("delete process is fail due to some error");
			});
		
	}
	
	 $scope.sortBYyrs = function()
	 {
		 studentService.sortedStudent().then(function(result){
		     $scope.students=result.data;
			 },function(error){
				  $log.error('Some Error in Getting Ascending  sort Records.', error);	 
			 });  
	 }
	 
	 
	 $scope.sortBYyrsDsc = function()
	 {
		 studentService.sortedStudentDsc().then(function(result){
		     $scope.students=result.data;
			 },function(error){
				  $log.error('Some Error in Getting Descending  sort Records.', error);	 
			 });  
	 }
	 
	 $scope.editStusent = function(id){
		 $state.go('edit',{id}); 
	 }
	
	
})
