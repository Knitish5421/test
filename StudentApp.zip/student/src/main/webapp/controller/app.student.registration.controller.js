app.controller("studentRegCtrl", function ($scope,$log,$window,$state,studentService){


	$scope.qualifications = ["10th","pu","graduation"];
	$scope.addfield = function()
						{ 
							$scope.show10th =false ;
							$scope.showPu = false;
							$scope.showdegree = false;
							 
							if($scope.qualification == "10th")
							{
								$scope.show10th = true;
								
							}
							else if($scope.qualification=="pu" )
							{
								$scope.showPu = true;
								$scope.show10th = true;
							}
							else
							{
								$scope.showPu = true;
								$scope.show10th = true;
								$scope.showdegree = true;
								
							}
								
						}
	$scope.addStudent = function(){
		var Masterlist = [];
		
		var tenthQualification =
			{
		    qualification:"TENTH",
		    instituteName : $scope.tenthInstituteName,
		    passingYear   : $scope.tenthPassoutYear,
		    marks         : $scope.tenthMarks,
			}
		Masterlist.push(tenthQualification);
		
		var puQualification =
		{
		qualification :"PU",		
	    instituteName : $scope.puInstituteName,
	    passingYear   : $scope.puPassoutYear,
	    marks         : $scope.puMarks,
		}
		if($scope.puInstituteName!=null)
		{
	      Masterlist.push(puQualification);
		}
		
		var graduationQualification =
		{
	    qualification :"GRADUATION",		
	    instituteName : $scope.graduationInstituteName,
	    passingYear   : $scope.graduationPassoutYear,
	    marks         : $scope.graduationMarks,
		}
		if($scope.graduationInstituteName!=null)
		{
	     Masterlist.push(graduationQualification);
		}
		
		var studentform =
		{
				 id   				: $scope.id,
				 name 				: $scope.name,
				 address			: $scope.address,
				 age  				: $scope.age,
				 gender				: $scope.gender,	
		        }
		
	           
		       studentform.qualificationList = Masterlist;
	  		   studentService.addStudent(studentform).then(function(result){
	  			 $state.go('summary');
	  		   },
	  		   function errorCallback(response) {
	  				alert("registration process is fail due to some error");
	  			});
		
	         }
	$scope.text= "ADD";
	$scope.title ="Registration";
	
 
                  
    })