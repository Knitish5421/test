app.controller("studentEditctrl", function ($scope,$log,$window,$state,$stateParams,studentService){
	
	   var id = $stateParams.id;
	   getDetailsById(id);
	   
	
	  
	   function getDetailsById(id) 
		{
			studentService.getDetailById(id).then(function(result){
		     var student=result.data;
		       $scope.id                 = student.id;  
		       $scope.name               = student.name;
			   $scope.address 			 = student.address;
			   $scope.age                = student.age;
			   $scope.gender 	         = student.gender;
			   $scope.tenthInstituteName = student.tenthInstituteName;
			   $scope.tenthPassoutYear   = student.tenthPassoutYear;
			   $scope.tenthMarks         = student.tenthMarks;
			   $scope.puInstituteName    = student.puInstituteName;
			   $scope.puPassoutYear      = student.puPassoutYear;
			   $scope.puMarks 			 = student.puMarks;
			   $scope.graduationInstituteName =student.graduationInstituteName;
			   $scope.graduationPassoutYear   = student.graduationPassoutYear;
			   $scope.graduationMarks         = student.graduationMarks;
			   $scope.qualification           = student.qualification;
			   $scope.gradeTenth              = student.gradeTenth;
			   $scope.gradePu                 = student.gradePu;
			   $scope.gradeGraduation         = student.gradeGraduation;
			   
			   if( student.gradeTenth!=null)
				   {
				   $scope.gradeShwo = true;
				   }
			   if( student.gradePu!=null)
			   {
				   $scope.puGradeShwo = true;
			   }
			   if( student.gradeGraduation!=null)
			   {
				   $scope.graduationGradeShwo = true;
			   }
			   
			   
			   if(student.qualification=="10th")
				   {
				   $scope.show10th = true;
				   }
			    
			   if(student.qualification=="pu")
			   { 
				   $scope.show10th = true;
					$scope.showPu = true;
			   }
			   if(student.qualification=="graduation")
				   {
				 
				    $scope.showPu = true;
					$scope.show10th = true;
					$scope.showdegree = true;
				   }
		     
			 },function(error){
				  $log.error('Some Error in Getting id by Records.', error);	 
			 });  
		} 
	  
	 
   
$scope.qualifications = ["10th","pu","graduation"];

$scope.addfield = function()
			{ 
				$scope.show10th =false ;
				$scope.showPu = false;
				$scope.showdegree = false;
				 
				
				if($scope.qualification =="10th" )
				{ 
					$scope.show10th = true;
					$scope.puInstituteName ='';
					$scope.puPassoutYear = '';
					$scope.puMarks       ='';
					$scope.graduationPassoutYear ='';
					$scope.graduationInstituteName= '';
					$scope.graduationMarks = '';
					
					
				}
				else if($scope.qualification== "pu")
				{  
					$scope.show10th = true;
					$scope.showPu = true;
					$scope.graduationPassoutYear ='';
					$scope.graduationInstituteName= '';
					$scope.graduationMarks = '';
					
				}
				else
				{
					$scope.showPu = true;
					$scope.show10th = true;
					$scope.showdegree = true;
					
				}
					
			}



	   $scope.addStudent = function(){
	
		   var Masterlist = [];
			
			var tenthQualification =
				{
			    qualification:"TENTH",
			    instituteName : $scope.tenthInstituteName,
			    passingYear   : $scope.tenthPassoutYear,
			    marks         : $scope.tenthMarks,
			    grade         : $scope.grade,
				}
			Masterlist.push(tenthQualification);
			
			if($scope.puInstituteName!="" && $scope.puInstituteName!=null)
			{
			var puQualification =
			{
			qualification :"PU",
		    instituteName : $scope.puInstituteName,
		    passingYear   : $scope.puPassoutYear,
		    marks         : $scope.puMarks,
			}
			
		      Masterlist.push(puQualification);
			}
			
			if($scope.graduationInstituteName!="" &&$scope.graduationInstituteName!=null)
			{
			var graduationQualification =
			{
			qualification :"GRADUATION",
		    instituteName : $scope.graduationInstituteName,
		    passingYear   : $scope.graduationPassoutYear,
		    marks         : $scope.graduationMarks,
			}
			
		     Masterlist.push(graduationQualification);
			}
			var studentform =
			{
					 id   				: $scope.id,
					 name 				: $scope.name,
					 address			: $scope.address,
					 age  				: $scope.age,
					 gender				: $scope.gender,	
			        }
			
		           
			       studentform.qualificationList = Masterlist;
			   studentService.editStudent(studentform).then(function(result){
				 $state.go('summary');
				  		   },
				  		   function errorCallback(response) {
				  				alert("edit process is fail due to some error");
				  			});
				
		         }
	   			$scope.text= "Update";
	   			$scope.title ="Modify Form";
	   			
	   		 
	
})